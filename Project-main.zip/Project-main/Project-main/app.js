//App.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const ejs = require('ejs');
const path = require('path');

const app = express();

//View engine configuration

app.set('view engine', 'ejs');

// Middleware to parse request bodies

app.use(bodyParser.urlencoded({ extended: false }));

// Middleware to analyze application/json

app.use(bodyParser.json());

//Setting up database connection

mongoose.connect('mongodb://127.0.0.1:27017/CarDealership');
mongoose.connection.on('connected', () => console.log('Connected'));
mongoose.connection.on('error', () => console.log('Connection failed with - ', err));

//Creating the schema for the database

const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    security_q: { type: String, required: true },
    security_a: { type: String, required: true },
    role: { type: String, enum: ['admin', 'salesperson'], default: 'salesperson' }
})

const CarSchema = new mongoose.Schema({
    make: String,
    model: String,
    year: Number,
    price: String,
    color: String,
    vin: { type: String, required: true, unique: true },
    Mileage: Number,
    image: Buffer
})

//Creating the model

const User = mongoose.model('User', UserSchema); //To Users

const Car = mongoose.model('Car', CarSchema); // To Cars


//Home page route (EJS)

app.get('/', (req, res) => {
    res.render('index');
});


//Register route

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', async (req, res) => {
    const { email, username, password, security_q, security_a, role } = req.body; //Extracting the information
  
    try {
        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password
    
        await User.create({ email, username, password: hashedPassword, security_q, security_a:hashedPassword, role }); // Create a new user with hashed password
    
        res.send('User registered successfully!')}
  
    catch (error) {
        console.log(error);
  
      res.status(500).send('Registration failed!'); // Send error response
  
    }
  
});

//Login route (Created)

app.get('/login', (req, res) => {
    res.render('login');
});

//Authentication middleware into the login route

app.post('/login', async (req, res) => {
    try {
  
      const user = await User.findOne({ email: req.body.email });
  
      if (!user) {
        return res.status(401).json({ message: 'Invalid Credentials' });
      }
  
      const passwordMatch = await bcrypt.compare(req.body.password, user.password);
  
      if (!passwordMatch) {
        return res.status(401).json({ message: 'Invalid Credentials' });
      }
  
      req.user = user;

      //If, successfully

      res.send('Login successful!');

      //If, not successfully

    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).send('Login failed!');
    }
});



//addCars route

app.get('/addCars', (req, res) => {
    res.render('addCars');
});
  
  app.post('/addCars', async (req, res) => {
    const { make, model, year, price, color, vin, mileage, image } = req.body; //Extracting the information
  
    try {
      await Cars.create({ make, model, year, price, color, vin, mileage, image }); //Creating an entry in the database
      res.send('Car added successfully!');
    }
  
    catch (error) {
  
      res.status(500).send('Registration failed!'); // Send error response
  
    }
  
});

//Setting up the port number

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));